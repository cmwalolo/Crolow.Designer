﻿using Crolow.Designer.Core.Geometry;
using Crolow.Designer.Core.Geometry.Paths;
using Crolow.Designer.Core.Geometry.Paths.Definitions;
using Crolow.Designer.Core.Scene.Nodes;
using Crolow.Designer.Core.Scene.Nodes.Objects;
using Crolow.Designer.Core.Transforms;
using Crolow.Designer.Graphics.Core.Attributes;
using Crolow.Designer.Graphics.Core.Providers.BaseProviders;

namespace Crolow.Designer.Graphics.Core.BaseProviders
{

    [ShapeProviderMapping(typeof(RectangleShape))]
    public class RecangleShapeProvider : SceneNodeProvider, ISceneNodeProvider
    {

        public override RectangleShape Create(SceneNode parentNode, Rect2D bounds)
        {
            return new RectangleShape
            {
                Name = "Rectangle",
                ParentId = parentNode.Id,
                ParentNode = parentNode,
                Canvas = bounds
            };
        }
        public override void BuildPath(SceneNode shape)
        {
            Rect2D rect = shape.Canvas;

            PathFigure figure = new()
            {
                StartPoint = new Point2D(rect.X, rect.Y),
                Closed = true
            };

            figure.Segments.Add(
                new LineSegment(new Point2D(rect.Right, rect.Y)));

            figure.Segments.Add(
                new LineSegment(new Point2D(rect.Right, rect.Bottom)));

            figure.Segments.Add(
                new LineSegment(new Point2D(rect.X, rect.Bottom)));

            shape.BasicPath = new PathGeometry();

            shape.BasicPath.Figures.Add(figure);
        }

        public void ApplyTransform(SceneNode node, TransformContent transformation, bool doNotUseContextCenter)
        {
            base.ApplyTransform(node, transformation, doNotUseContextCenter);
        }

        public Rect2D GetBounds(SceneNode node)
        {
            return this.GetBounds(node);
        }

        public bool IsInBounds(SceneNode node, Rect2D selection)
        {
            return base.IsInBounds(node, selection);
        }

        public bool HitTest(SceneNode node, Point2D point)
        {
            return base.HitTest(node, point);
        }

        public void Render(SceneNode node)
        {
            base.Render(node);
        }
    }
}
