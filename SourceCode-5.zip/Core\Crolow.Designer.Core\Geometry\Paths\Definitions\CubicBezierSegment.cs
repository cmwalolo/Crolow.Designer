namespace Crolow.Designer.Core.Geometry.Paths.Definitions;

public class CubicBezierSegment : PathSegment
{
    public CubicBezierSegment(Point2D point) : base(point)
    {
    }

    public Point2D Control1 { get; set; }

    public Point2D Control2 { get; set; }
}
