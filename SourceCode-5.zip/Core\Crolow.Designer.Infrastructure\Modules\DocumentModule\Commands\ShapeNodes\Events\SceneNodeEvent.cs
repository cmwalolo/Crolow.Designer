﻿using Crolow.Designer.Common.Constants;
using Crolow.Designer.Common.Event;
using Crolow.Designer.Core.Scene.Nodes;

namespace Crolow.Designer.Runtime.Modules.DocumentModule.Commands.GroupNodes.Events;

public sealed record SceneNodeEvent : IEvent<GroupNode, SceneNode>
{
    public SceneNodeEvent(Guid refId, GroupNode source, List<SceneNode> target)
    {
        ReferenceId = refId;
        Source = source;
        Target = target;
    }

    public SceneNodeEvent(Guid refId, GroupNode source, SceneNode target)
    {
        ReferenceId = refId;
        Source = source;
        Target = new List<SceneNode> { target };
    }

    public Guid ReferenceId { get; }
    public EventTarget EventTarget { get; } = EventTarget.DocumentSessions;
    public EventAction EventAction { get; } = EventAction.ObjectCreated;
    public GroupNode Source { get; }
    public List<SceneNode> Target { get; }
}