﻿#region Demo

using Crolow.Designer.Runtime.Application;
using Crolow.Designer.Runtime.Modules.DocumentModule.Commands.Requests;

public static class Program
{
    public static async Task Main()
    {
        var runtime = new DesignerRuntime();

        var document =
            await runtime.Commands.ExecuteAsync(
                new CreateDocumentCommand(
                    "Landing Page"));

        var layer = await runtime.Commands.ExecuteAsync(
                new CreateLayerCommand(
                    document,
                    "Desktop"));

        await runtime.Commands.ExecuteAsync(
            new CreateRectangleCommand(
                layer,
                "Header"));
        await runtime.Commands.ExecuteAsync(
            new CreateRectangleCommand(
                layer,
                "Hero Banner"));

        var layer2 = await runtime.Commands.ExecuteAsync(
                new CreateLayerCommand(
                    document,
                    "Desktop"));

        await runtime.Commands.ExecuteAsync(
            new CreateRectangleCommand(
                layer2,
                "Header"));
        await runtime.Commands.ExecuteAsync(
            new CreateRectangleCommand(
                layer2,
                "Hero Banner"));


        var layers = document.Layers.Count();
        var objects = document.Layers.SelectMany(x => x.Children).Count();

        Console.WriteLine(
            $"# Layers : {layers}");
        Console.WriteLine(
            $"# Objects : {objects}");

    }
}
#endregion
