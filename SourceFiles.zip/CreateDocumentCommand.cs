﻿using Crolow.Designer.Core.Document;
using Crolow.Designer.Runtime.Application.Commands;

namespace Crolow.Designer.Runtime.Modules.DocumentModule.Commands.Requests;
#region Results

#endregion


public sealed record CreateDocumentCommand(
    string Name)
    : ICommand<DesignDocument>;
