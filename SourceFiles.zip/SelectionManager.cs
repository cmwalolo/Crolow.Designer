﻿namespace Crolow.Designer.Runtime.Application.Sessions
{
    public sealed class SelectionManager
    {
        private readonly HashSet<Guid> _selectedIds = [];

        public IReadOnlyCollection<Guid> SelectedIds
            => _selectedIds;

        public void Clear()
        {
        }

        public void Set(Guid id)
        {
        }

        public void Set(IEnumerable<Guid> ids)
        {
        }

        public void Add(Guid id)
        {
        }

        public void Add(IEnumerable<Guid> ids)
        {
        }

        public void Remove(Guid id)
        {
        }

        public bool IsSelected(Guid id)
        {
            return true;
        }
    }
}
