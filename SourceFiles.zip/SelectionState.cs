﻿namespace Crolow.Designer.Runtime.Application.Sessions.States
{
    public sealed class SelectionTreeState
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public HashSet<Guid> Childrens { get; set; } = [];
    }
}
