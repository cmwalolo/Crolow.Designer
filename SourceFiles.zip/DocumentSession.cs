﻿using Crolow.Designer.Core.Document;

namespace Crolow.Designer.Runtime.Modules.DocumentModule
{
    public class DocumentSession
    {
        public DesignDocument Document { get; set; }
    }
}
