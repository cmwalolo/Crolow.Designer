﻿using Crolow.Designer.Core.Document;
using Crolow.Designer.Runtime.Application.Commands;

namespace Crolow.Designer.Runtime.Modules.DocumentModule.Commands.Requests;

public sealed record CreateLayerCommand(
    DesignDocument Document,
    string Name)
    : ICommand<Layer>;
