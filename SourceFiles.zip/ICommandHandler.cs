﻿namespace Crolow.Designer.Runtime.Application.Commands;

public interface ICommandHandler<TCommand, TResult>
    where TCommand : ICommand<TResult>
{
    Task<TResult> ExecuteAsync(
        TCommand command);
}
