﻿namespace Crolow.Designer.Runtime.Application.Commands;

public interface ICommand<TResult>
{
}
