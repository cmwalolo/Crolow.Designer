﻿using Crolow.Designer.Core.Document;
using Crolow.Designer.Runtime.Application;
using Crolow.Designer.Runtime.Application.Commands;
using Crolow.Designer.Runtime.Application.Events;
using Crolow.Designer.Runtime.Modules.DocumentModule.Commands.Requests;

namespace Crolow.Designer.Runtime.Modules.DocumentModule.Commands;

public sealed class CreateLayerCommandHandler
    : ICommandHandler<
        CreateLayerCommand,
        Layer>
{
    private readonly DesignerRuntime _runtime;

    public CreateLayerCommandHandler(
        DesignerRuntime runtime)
    {
        _runtime = runtime;
    }

    public async Task<Layer>
        ExecuteAsync(
            CreateLayerCommand command)
    {
        var layer =
            new Layer
            {
                Name = command.Name
            };

        command.Document.Layers.Add(
            layer);

        await _runtime.Events.PublishAsync(
            new LayerCreatedEvent(
                command.Document,
                layer));

        return layer;
    }
}
